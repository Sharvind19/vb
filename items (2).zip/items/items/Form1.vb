﻿Imports System.Data.OleDb

Public Class Form1
    Private connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\sharv\OneDrive\Documents\Database6.accdb;Persist Security Info=True"

    Private Sub DisplayButton_Click(sender As Object, e As EventArgs) Handles DisplayButton.Click
        ' Get the selected payment method
        Dim paymentMethod As String
        If RadioButton1.Checked Then
            paymentMethod = "Online"
        ElseIf RadioButton2.Checked Then
            paymentMethod = "Cash"
        Else
            MessageBox.Show("Please select a payment method.")
            Return
        End If

        ' Display text from TextBox in DataGridView
        Dim productName As String = TextBox1.Text
        Dim quantity As Integer
        Dim price As Double

        ' Validate quantity input
        If Not Integer.TryParse(TextBox2.Text, quantity) Then
            MessageBox.Show("Invalid input for quantity. Please enter a valid integer value.")
            Return
        End If

        ' Validate price input
        If Not Double.TryParse(TextBox3.Text, price) Then
            MessageBox.Show("Invalid input for price. Please enter a valid numeric value.")
            Return
        End If

        Dim amount As Double = quantity * price

        ' Insert data into the Access database
        InsertDataIntoDatabase(productName, quantity, price, amount, paymentMethod)

        ' Refresh DataGridView
        RefreshDataGridView()
    End Sub

    Private Sub InsertDataIntoDatabase(productName As String, quantity As Integer, price As Double, amount As Double, paymentMethod As String)
        Try
            Using connection As New OleDbConnection(connectionString)
                connection.Open()
                Dim query As String = "INSERT INTO Sales (Item, Quantity, Price, Amount, PaymentMethod) VALUES (?, ?, ?, ?, ?)"
                Using command As New OleDbCommand(query, connection)
                    command.Parameters.AddWithValue("?", productName)
                    command.Parameters.AddWithValue("?", quantity)
                    command.Parameters.AddWithValue("?", price)
                    command.Parameters.AddWithValue("?", amount)
                    command.Parameters.AddWithValue("?", paymentMethod)
                    command.ExecuteNonQuery()
                End Using
            End Using
            MessageBox.Show("Data inserted successfully.")
        Catch ex As Exception
            MessageBox.Show("Error inserting data: " & ex.Message)
        End Try
    End Sub

    Private Sub RefreshDataGridView()
        ' Clear DataGridView
        DataGridView1.DataSource = Nothing
        DataGridView1.Rows.Clear()

        ' Reload data from database
        Dim adapter As New OleDbDataAdapter("SELECT * FROM Sales", connectionString)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub NextButton_Click(sender As Object, e As EventArgs) Handles NextButton.Click
        ' Move to Form2
        Dim form2 As New Form2(Me)
        form2.Show()
        Me.Hide()
    End Sub

    Private Sub CalculateButton_Click(sender As Object, e As EventArgs) Handles CalculateButton.Click
        ' Calculate the amount
        Dim quantity As Integer
        Dim price As Double

        ' Validate quantity input
        If Not Integer.TryParse(TextBox2.Text, quantity) Then
            MessageBox.Show("Invalid input for quantity. Please enter a valid integer value.")
            Return
        End If

        ' Validate price input
        If Not Double.TryParse(TextBox3.Text, price) Then
            MessageBox.Show("Invalid input for price. Please enter a valid numeric value.")
            Return
        End If

        Dim amount As Double = quantity * price
        MessageBox.Show("Amount: " & amount.ToString())
    End Sub

    Private Sub ShowButton_Click(sender As Object, e As EventArgs) Handles ShowButton.Click
        ' Show output in MessageBox
        Try
            Dim productName As String = TextBox1.Text
            Dim quantity As Integer = Convert.ToInt32(TextBox2.Text)
            Dim price As Double = Convert.ToDouble(TextBox3.Text)
            Dim amount As Double = quantity * price
            Dim paymentMethod As String
            If RadioButton1.Checked Then
                paymentMethod = "Online"
            ElseIf RadioButton2.Checked Then
                paymentMethod = "Cash"
            Else
                MessageBox.Show("Please select a payment method.")
                Return
            End If
            MessageBox.Show("Item: " & productName & vbCrLf & "Quantity: " & quantity.ToString() & vbCrLf & "Price: " & price.ToString() & vbCrLf & "Amount: " & amount.ToString() & vbCrLf & "Payment Method: " & paymentMethod)
        Catch ex As FormatException
            MessageBox.Show("Invalid input for quantity or price. Please enter valid numeric values.")
        End Try
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        ' Placeholder for any TextBox2 specific logic
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SalesDataSet.Sales' table. You can move, or remove it, as needed.
        Me.SalesTableAdapter1.Fill(Me.SalesDataSet.Sales)
        ' Load data into DataGridView
        RefreshDataGridView()
    End Sub
End Class
