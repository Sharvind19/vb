﻿Public Class Form2
    Private mainForm As Form1

    Public Sub New(parent As Form1)
        InitializeComponent()
        mainForm = parent
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        ' Go back to Form1
        mainForm.Show()
        Me.Close()
    End Sub
End Class