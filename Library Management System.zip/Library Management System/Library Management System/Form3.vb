﻿Imports System.Data.OleDb
Imports Microsoft.Win32

Public Class Form3

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Table_BookManagementDataSet.BookManagement' table. You can move, or remove it, as needed.
        Me.BookManagementTableAdapter.Fill(Me.Table_BookManagementDataSet.BookManagement)
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        MessageBox.Show("Data submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim Username As String = txtUsername.Text.Trim()
        Dim icNumber As String = txtIC.Text.Trim()
        Dim phoneNumber As String = txtPhone.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim address As String = txtAddress.Text.Trim()
        Dim ID As String = txtID.Text.Trim()
        Dim bookName As String = txtName.Text.Trim()
        Dim bookYear As String = txtYear.Text.Trim()
        Dim bookLanguage As String = txtLanguage.Text.Trim()
        Dim collectDate As String = dtpCollect.Text.Trim()
        Dim returnDate As String = dtpReturn.Text.Trim()

        ' Add a new row to the DataGridView
        Dim newRow As DataGridViewRow = New DataGridViewRow()
        newRow.CreateCells(BookingView)
        newRow.Cells(0).Value = Username
        newRow.Cells(1).Value = icNumber
        newRow.Cells(2).Value = phoneNumber
        newRow.Cells(3).Value = email
        newRow.Cells(4).Value = address
        newRow.Cells(5).Value = ID
        newRow.Cells(6).Value = bookName
        newRow.Cells(7).Value = bookYear
        newRow.Cells(8).Value = bookLanguage
        newRow.Cells(9).Value = collectDate
        newRow.Cells(10).Value = returnDate

        BookingView.Rows.Add(newRow)

        Try
            ' Open the connection
            DatabaseConnection.conn.Open()

            ' Check if the book name already exists
            Dim selectCommand As New OleDbCommand("SELECT COUNT(*) FROM table_BookManagement WHERE [Name] = @Name", DatabaseConnection.conn)
            selectCommand.Parameters.AddWithValue("@Name", bookName)

            Dim existingRecordsCount As Integer = CInt(selectCommand.ExecuteScalar())

            If existingRecordsCount = 0 Then
                ' No existing records found, proceed with registration
                Dim insertCommand As New OleDbCommand("INSERT INTO BookManagement ([Name], [ICNumber], [PhoneNumber], [Email], [Address], [ID], [BookName], [BookYear], [BookLanguage], [CollectDate], [ReturnDate]) VALUES (@Name, @ICNumber, @PhoneNumber, @Email, @Address, @ID, @BookName, @BookYear, @BookLanguage, @CollectDate, @ReturnDate)", DatabaseConnection.conn)
                insertCommand.Parameters.AddWithValue("@Name", Username)
                insertCommand.Parameters.AddWithValue("@ICNumber", icNumber)
                insertCommand.Parameters.AddWithValue("@PhoneNumber", phoneNumber)
                insertCommand.Parameters.AddWithValue("@Email", email)
                insertCommand.Parameters.AddWithValue("@Address", address)
                insertCommand.Parameters.AddWithValue("@ID", ID)
                insertCommand.Parameters.AddWithValue("@BookName", bookName)
                insertCommand.Parameters.AddWithValue("@BookYear", bookYear)
                insertCommand.Parameters.AddWithValue("@BookLanguage", bookLanguage)
                insertCommand.Parameters.AddWithValue("@CollectDate", collectDate)
                insertCommand.Parameters.AddWithValue("@ReturnDate", returnDate)

                ' Execute insertion command
                insertCommand.ExecuteNonQuery()

                MessageBox.Show("Registration successful.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                ' Display an error message indicating duplicate records
                MessageBox.Show("A book with the same name already exists. Please provide a unique book name.", "Duplicate Records", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred while registering data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            DatabaseConnection.conn.Close()
        End Try

        ' Clear fields after registration
        ClearFormFields()
    End Sub

    Private Sub ClearFormFields()
        ' Clear form fields after adding
        txtUsername.Clear()
        txtIC.Clear()
        txtPhone.Clear()
        txtEmail.Clear()
        txtAddress.Clear()
        txtID.Clear()
        txtName.Clear()
        txtYear.Clear()
        txtLanguage.Clear()
        dtpCollect.Value = DateTime.Now ' Reset date to current date
        dtpReturn.Value = DateTime.Now ' Reset date to current date
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' Prompt the user to enter the book name
        Dim bookName As String = txtName.Text.Trim()
        If Not String.IsNullOrEmpty(bookName) Then
            Try
                ' Open the database connection
                DatabaseConnection.conn.Open()

                ' Create the delete command
                Dim deleteCommand As New OleDbCommand("DELETE FROM BookManagement WHERE [BookName] = @BookName", DatabaseConnection.conn)
                deleteCommand.Parameters.AddWithValue("@BookName", bookName)

                ' Execute the delete command
                Dim rowsAffected As Integer = deleteCommand.ExecuteNonQuery()

                ' Check if any row was deleted
                If rowsAffected > 0 Then
                    ' Refresh the DataGridView
                    LoadDataIntoDataGridView() ' Assume this method loads data into the DataGridView
                    MessageBox.Show("Data for Book Name: " & bookName & " has been successfully deleted.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtName.Text = ""
                Else
                    MessageBox.Show("No data found for Book Name: " & bookName & ".", "Data Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If
            Catch ex As Exception
                MessageBox.Show("An error occurred while deleting data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                ' Close the database connection
                DatabaseConnection.conn.Close()
            End Try
        Else
            MessageBox.Show("Please enter a Book Name to delete data.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub LoadDataIntoDataGridView()
        Try
            If DatabaseConnection.conn.State = ConnectionState.Closed Then
                DatabaseConnection.conn.Open()
            End If

            DatabaseConnection.dbcmd = New OleDb.OleDbCommand("SELECT * FROM BookManagement", DatabaseConnection.conn)
            DatabaseConnection.dta = New OleDbDataAdapter(DatabaseConnection.cmd)
            DatabaseConnection.dts.Clear()
            DatabaseConnection.dta.Fill(DatabaseConnection.dts, "BookManagement")
            BookingView.DataSource = DatabaseConnection.dts.Tables("BookManagement")
        Catch ex As Exception
            MsgBox("Error fetching data: " & ex.Message, MsgBoxStyle.Critical)
        Finally
            If DatabaseConnection.conn.State = ConnectionState.Open Then
                DatabaseConnection.conn.Close()
            End If
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Prompt the user to enter the book name
        Dim bookName As String = InputBox("Enter the Book Name of the data you want to update:", "Update Data")
        ' Check if the user entered a book name
        If Not String.IsNullOrEmpty(bookName) Then
            Try
                DatabaseConnection.conn.Open()

                ' Execute SELECT query to retrieve data for the entered book name
                Dim selectCommand As New OleDbCommand("SELECT * FROM BookManagement WHERE [BookName] = @BookName", DatabaseConnection.conn)
                selectCommand.Parameters.AddWithValue("@BookName", bookName)

                ' Create a DataAdapter and DataSet to store the retrieved data
                Dim dataAdapter As New OleDbDataAdapter(selectCommand)
                Dim dataSet As New DataSet()

                ' Fill the DataSet with the retrieved data
                dataAdapter.Fill(dataSet, "BookManagement")

                ' Check if any rows were returned
                If dataSet.Tables("BookManagement").Rows.Count > 0 Then
                    ' Prompt user to choose book language
                    Dim bookLanguage As String = ""
                    Dim bookLanguageDialogResult As DialogResult = MessageBox.Show("Choose the Book Language", "Book Language", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                    If bookLanguageDialogResult = DialogResult.Yes Then
                        bookLanguage = "English"
                    ElseIf bookLanguageDialogResult = DialogResult.No Then
                        bookLanguage = "Other"
                    Else
                        MessageBox.Show("Please select a book language.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Exit Sub ' Exit the subroutine if no book language is chosen
                    End If

                    ' Execute UPDATE query to update the selected fields with new values
                    Dim updateCommand As New OleDbCommand("UPDATE BookManagement SET BookYear = @BookYear, BookLanguage = @BookLanguage WHERE [BookName] = @BookName", DatabaseConnection.conn)
                    updateCommand.Parameters.AddWithValue("@BookYear", txtYear.Text.Trim())
                    updateCommand.Parameters.AddWithValue("@BookLanguage", bookLanguage)
                    updateCommand.Parameters.AddWithValue("@BookName", bookName)

                    updateCommand.ExecuteNonQuery()

                    MessageBox.Show("Data updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    ' Refresh the DataGridView after updating
                    LoadDataIntoDataGridView()
                Else
                    MessageBox.Show("No data found for the entered Book Name.", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                MessageBox.Show("An error occurred while updating data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                If DatabaseConnection.conn.State <> ConnectionState.Closed Then
                    DatabaseConnection.conn.Close()
                End If
            End Try
        Else
            MessageBox.Show("Please enter a Book Name.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If

        ' Clear fields after updating
        ClearFormFields()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Display a confirmation message box
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        ' If the user clicks "Yes," close the form
        If result = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
End Class

