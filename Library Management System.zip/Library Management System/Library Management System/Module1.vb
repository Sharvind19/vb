﻿Imports System.Data.OleDb

Module DatabaseConnection
    Public dts As New DataSet
    Public dbcmd As New OleDbCommand
    Public dta As OleDbDataAdapter
    Public conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\brunt\Documents\table_register.accdb")
End Module
