﻿Imports System.Data.OleDb
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel
Public Class Form2
    Public Property DatabaseConnection As Object

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        ' Get the data entered by the user
        RegisterView.DataSource = Nothing
        Dim username As String = txtUsername.Text.Trim()
        Dim password As String = txtPass.Text.Trim()
        Dim gender As String = cbGender.Text.Trim()
        Dim icNumber As String = txtIC.Text.Trim()
        Dim phoneNumber As String = txtPhone.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim address As String = txtAddress.Text.Trim()

        ' Add a new row to the DataGridView
        Dim newRow As DataGridViewRow = New DataGridViewRow()
        newRow.CreateCells(RegisterView)
        newRow.Cells(0).Value = username
        newRow.Cells(1).Value = password
        newRow.Cells(2).Value = gender
        newRow.Cells(3).Value = icNumber
        newRow.Cells(4).Value = phoneNumber
        newRow.Cells(5).Value = email
        newRow.Cells(6).Value = address


        RegisterView.Rows.Add(newRow)

        Try
            ' Open the connection
            DatabaseConnection.con.Open()

            ' Check if the matrix number, name, username, and password already exist
            Dim selectCommand As New OleDbCommand("SELECT COUNT(*) FROM table_Register WHERE [IC Number] = @IC_Number OR [Phone Number] = @Phone_Number OR [Email] = @Email OR [Address] = @Address", DatabaseConnection.con)
            selectCommand.Parameters.AddWithValue("@IC_Number", icNumber)
            selectCommand.Parameters.AddWithValue("@Phone_Number", phoneNumber)
            selectCommand.Parameters.AddWithValue("@Email", email)
            selectCommand.Parameters.AddWithValue("@Address", address)


            Dim existingRecordsCount As Integer = CInt(selectCommand.ExecuteScalar())

            If existingRecordsCount = 0 Then
                ' No existing records found, proceed with registration
                Dim insertCommand As New OleDbCommand("INSERT INTO Registration ([Username], [Password], [Gender], [IC Number], [Phone Number], [Email], [Address]) VALUES (@Username, @Password, @Gender, @IC_Number, @Phone_Number, @Email, @Address)", DatabaseConnection.con)
                insertCommand.Parameters.AddWithValue("@Username", username)
                insertCommand.Parameters.AddWithValue("@Password", password)
                insertCommand.Parameters.AddWithValue("@Gender", gender)
                insertCommand.Parameters.AddWithValue("@IC_Number", icNumber)
                insertCommand.Parameters.AddWithValue("@Phone_Number", phoneNumber)
                insertCommand.Parameters.AddWithValue("@Email", email)
                insertCommand.Parameters.AddWithValue("@Address", address)

                ' Execute insertion command
                insertCommand.ExecuteNonQuery()

                MessageBox.Show("Registration successful.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                ' Display an error message indicating duplicate records
                MessageBox.Show("A user with the same matrix number, name, username, or password already exists. Please provide unique information.", "Duplicate Records", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred while registering data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            DatabaseConnection.conn.Close()
        End Try

        ' Clear fields after registration
        ClearFormFields()
    End Sub

    Private Sub ClearFormFields()
        txtUsername.Clear()
        txtPass.Clear()
        cbGender.SelectedIndex = -1
        txtIC.Clear()
        txtPhone.Clear()
        txtEmail.Clear()
        txtAddress.Clear()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load data from the database when the form loads
        LoadDataIntoDataGridView()
    End Sub

    Private Sub LoadDataIntoDataGridView()
        Try
            If DatabaseConnection.con.State = ConnectionState.Closed Then
                DatabaseConnection.con.Open()
            End If

            DatabaseConnection.cmd = New OleDb.OleDbCommand("SELECT * FROM Registration", DatabaseConnection.con)
            DatabaseConnection.da = New OleDbDataAdapter(DatabaseConnection.cmd)
            DatabaseConnection.ds.Clear()
            DatabaseConnection.da.Fill(DatabaseConnection.ds, "Registration")
            RegisterView.DataSource = DatabaseConnection.ds.Tables("Registration")
        Catch ex As Exception
            MsgBox("Error fetching data: " & ex.Message, MsgBoxStyle.Critical)


        End Try
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' Prompt the user to enter the username
        Dim username As String = txtUsername.Text.Trim()
        If Not String.IsNullOrEmpty(username) Then
            Try
                DatabaseConnection.conn.Open()

                Dim deleteCommand As New OleDbCommand("DELETE FROM Registration WHERE [Username] = @Username", DatabaseConnection.con)
                deleteCommand.Parameters.AddWithValue("@Username", username)

                deleteCommand.ExecuteNonQuery()

                ' Remove the deleted row from the DataGridView's DataSource
                Dim dt As DataTable = DirectCast(RegisterView.DataSource, DataTable)
                If dt IsNot Nothing Then
                    Dim rows As DataRow() = dt.Select("[Username] = '" & username & "'")
                    For Each row In rows
                        dt.Rows.Remove(row)
                    Next
                End If

                MessageBox.Show("Data for Username: " & username & " has been successfully deleted.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("An error occurred while deleting data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                DatabaseConnection.conn.Close()
            End Try
        Else
            MessageBox.Show("Please enter a Username to delete data.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Prompt the user to enter the username
        Dim usernameToUpdate As String = InputBox("Enter username to update:")

        ' Check if Matrix Number is provided
        If Not String.IsNullOrEmpty(usernameToUpdate) Then
            Try
                ' Open the connection
                DatabaseConnection.conn.Open()

                ' Select the data based on the Matrix Number
                Dim selectCommand As New OleDbCommand("SELECT * FROM Registration WHERE [Username] = @Username", DatabaseConnection.con)
                selectCommand.Parameters.AddWithValue("@Username", usernameToUpdate)

                ' Execute the command and get the data
                Dim reader As OleDbDataReader = selectCommand.ExecuteReader()

                ' Check if any data is returned
                If reader.Read() Then
                    ' Display the data to the user
                    Dim password As String = reader("Password").ToString()
                    Dim gender As String = reader("Gender").ToString()
                    Dim icNumber As String = reader("IC Number").ToString()
                    Dim phoneNumber As String = reader("Contact Number").ToString()
                    Dim email As String = reader("Email").ToString()
                    Dim address As String = reader("Address").ToString()

                    reader.Close() ' Close the data reader before prompting the user

                    Dim userInput As String = InputBox("Which data do you want to update?" & vbCrLf &
                                                    "1. Password: " & password & vbCrLf &
                                                    "2. Gender: " & gender & vbCrLf &
                                                    "3. IC Number: " & icNumber & vbCrLf &
                                                    "4. Contact Number: " & phoneNumber & vbCrLf &
                                                    "5. Email: " & email & vbCrLf &
                                                    "6. Address: " & address & vbCrLf &
                                                    "Enter the number corresponding to the data you want to update:")

                    ' Prompt the user to enter the new value for the selected data
                    Dim newValue As String = InputBox("Enter the new value:")

                    ' Update the selected data in the database based on the user's choice
                    Dim updateCommand As OleDbCommand
                    Select Case userInput
                        Case "1"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [Password] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case "2"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [Gender] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case "3"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [IC Number] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case "4"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [Contact Number] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case "5"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [Email] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case "6"
                            updateCommand = New OleDbCommand("UPDATE Registration SET [Address] = @NewValue WHERE [Username] = @Username", DatabaseConnection.conn)
                        Case Else
                            MessageBox.Show("Invalid choice. Please enter a number from 1 to 6.", "Invalid Choice", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            Exit Sub
                    End Select

                    updateCommand.Parameters.AddWithValue("@NewValue", newValue)
                    updateCommand.Parameters.AddWithValue("@Username", usernameToUpdate)

                    updateCommand.ExecuteNonQuery()

                    MessageBox.Show("Data updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("No data found for the provided username.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If

                ' Reload the data into the DataGridView
                UpdateSub()

            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                ' Close the connection
                If DatabaseConnection.conn.State <> ConnectionState.Closed Then
                    DatabaseConnection.conn.Close()
                End If
            End Try
        Else
            MessageBox.Show("Please enter a Username to update data.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub UpdateSub()
        Throw New NotImplementedException()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        ' Prompt the user to enter the Username to search
        Dim usernameToSearch As String = InputBox("Enter Username to search:")

        ' Check if Username is provided
        If Not String.IsNullOrEmpty(usernameToSearch) Then
            Try
                ' Open the connection
                DatabaseConnection.conn.Open()

                ' Select the data based on the Username
                Dim selectCommand As New OleDbCommand("SELECT * FROM Registration WHERE [Username] = @Username", DatabaseConnection.conn)
                selectCommand.Parameters.AddWithValue("@Username", usernameToSearch)

                ' Execute the command and get the data
                Dim adapter As New OleDbDataAdapter(selectCommand)
                Dim dataset As New DataSet()
                adapter.Fill(dataset, "Registration")

                ' Check if any data is returned
                If dataset.Tables("Registration").Rows.Count > 0 Then
                    ' Data found, display in DataGridView
                    RegisterView.DataSource = dataset.Tables("Registration")
                    MessageBox.Show("Data found for Username: " & usernameToSearch & ".", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    RegisterView.DataSource = Nothing
                    MessageBox.Show("No data found for the provided Username.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                DatabaseConnection.conn.Close()
            End Try
        Else
            MessageBox.Show("Please enter a Username to search.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Form3.Show()
    End Sub
End Class